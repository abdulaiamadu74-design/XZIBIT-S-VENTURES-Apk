XZIBIT VENTURES Android app project

This app opens the existing store directly:
https://buygh.link/88104

The app requires an internet connection. This ZIP is source code, not an APK.
Use the GitHub Actions workflow instructions in the chat to build the APK online.
